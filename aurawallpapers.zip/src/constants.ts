export interface Wallpaper {
  id: string;
  url: string;
  title: string;
  category: string;
  author?: string;
  isAI?: boolean;
}

export const CATEGORIES = [
  "All",
  "Nature",
  "Abstract",
  "Architecture",
  "Space",
  "Minimal",
  "Cyberpunk",
  "AI Generated",
  "Favorites"
];

export const AI_STYLE_PRESETS = [
  { id: 'cinematic', label: 'Cinematic', prompt: 'cinematic lighting, high detail, 8k, professional photography' },
  { id: 'minimalist', label: 'Minimalist', prompt: 'minimalist, clean lines, simple composition, flat design' },
  { id: 'cyberpunk', label: 'Cyberpunk', prompt: 'cyberpunk aesthetic, neon lights, futuristic, dark atmosphere' },
  { id: 'oil-painting', label: 'Oil Painting', prompt: 'oil painting style, thick brushstrokes, classical art' },
  { id: '3d-render', label: '3D Render', prompt: 'octane render, 3d isometric, unreal engine 5, stylized' },
  { id: 'anime', label: 'Anime', prompt: 'anime style, vibrant colors, studio ghibli inspired' },
];

export const INITIAL_WALLPAPERS: Wallpaper[] = [
  { id: '1', url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1080&q=80', title: 'Mountain Peaks', category: 'Nature' },
  { id: '2', url: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1080&q=80', title: 'Abstract Flow', category: 'Abstract' },
  { id: '3', url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1080&q=80', title: 'Glass Tower', category: 'Architecture' },
  { id: '4', url: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1080&q=80', title: 'Earth from Orbit', category: 'Space' },
  { id: '5', url: 'https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=1080&q=80', title: 'Minimal Lamp', category: 'Minimal' },
  { id: '6', url: 'https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=1080&q=80', title: 'Neon Grid', category: 'Cyberpunk' },
  { id: '7', url: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1080&q=80', title: 'Sunlight Forest', category: 'Nature' },
  { id: '8', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=1080&q=80', title: 'Geometric Shapes', category: 'Abstract' },
  { id: '9', url: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=1080&q=80', title: 'City Skyline', category: 'Architecture' },
  { id: '10', url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1080&q=80', title: 'Digital Nebula', category: 'Space' },
];
