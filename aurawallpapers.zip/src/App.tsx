/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Sparkles, 
  Download, 
  Maximize2, 
  X, 
  Smartphone, 
  Grid, 
  Heart,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Image as ImageIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { cn } from './lib/utils';
import { CATEGORIES, INITIAL_WALLPAPERS, Wallpaper, AI_STYLE_PRESETS } from './constants';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [wallpapers, setWallpapers] = useState<Wallpaper[]>(INITIAL_WALLPAPERS);
  const [selectedWallpaper, setSelectedWallpaper] = useState<Wallpaper | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isAIGenerating, setIsAIGenerating] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState(AI_STYLE_PRESETS[0].id);
  const [showAIModal, setShowAIModal] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  // Filter wallpapers based on search and category
  const filteredWallpapers = useMemo(() => {
    return wallpapers.filter(wp => {
      const matchesSearch = wp.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = 
        selectedCategory === 'All' || 
        (selectedCategory === 'Favorites' ? favorites.includes(wp.id) : wp.category === selectedCategory);
      return matchesSearch && matchesCategory;
    });
  }, [wallpapers, searchQuery, selectedCategory, favorites]);

  const toggleFavorite = (id: string) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    );
  };

  const handleGenerateAI = async () => {
    if (!aiPrompt.trim()) return;
    setIsAIGenerating(true);
    try {
      const style = AI_STYLE_PRESETS.find(s => s.id === selectedStyle);
      const fullPrompt = `${aiPrompt}. Style: ${style?.prompt}. Vertical orientation, mobile wallpaper, 9:16 aspect ratio, high resolution.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: fullPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: "9:16",
          }
        }
      });

      let imageUrl = '';
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        const newWallpaper: Wallpaper = {
          id: Date.now().toString(),
          url: imageUrl,
          title: aiPrompt,
          category: 'AI Generated',
          isAI: true
        };
        setWallpapers(prev => [newWallpaper, ...prev]);
        setShowAIModal(false);
        setAiPrompt('');
      }
    } catch (error) {
      console.error("AI Generation failed:", error);
    } finally {
      setIsAIGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-orange-500/30">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-rose-600 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
              Aura<span className="text-orange-500">Wallpapers</span>
            </h1>
          </div>

          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40 group-focus-within:text-orange-500 transition-colors" />
              <input 
                type="text"
                placeholder="Search wallpapers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-full py-2.5 pl-11 pr-4 focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500/50 transition-all placeholder:text-white/20"
              />
            </div>
          </div>

          <button 
            onClick={() => setShowAIModal(true)}
            className="flex items-center gap-2 bg-white text-black px-5 py-2.5 rounded-full font-semibold hover:bg-orange-500 hover:text-white transition-all active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Generate</span>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Categories */}
        <div className="flex items-center gap-3 overflow-x-auto pb-6 scrollbar-hide no-scrollbar">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={cn(
                "px-6 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all border",
                selectedCategory === cat 
                  ? "bg-white text-black border-white" 
                  : "bg-white/5 text-white/60 border-white/10 hover:border-white/30"
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
          <AnimatePresence mode="popLayout">
            {filteredWallpapers.map((wp, idx) => (
              <motion.div
                key={wp.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: idx * 0.05 }}
                className="group relative aspect-[9/16] rounded-2xl overflow-hidden cursor-pointer bg-white/5"
                onClick={() => {
                  setSelectedWallpaper(wp);
                  setIsPreviewOpen(true);
                }}
              >
                <img 
                  src={wp.url} 
                  alt={wp.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <p className="text-sm font-medium text-white truncate">{wp.title}</p>
                    <p className="text-xs text-white/60">{wp.category}</p>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(wp.id);
                    }}
                    className="absolute top-4 right-4 p-2 bg-black/20 backdrop-blur-md rounded-full hover:bg-white/20 transition-colors"
                  >
                    <Heart className={cn("w-4 h-4", favorites.includes(wp.id) ? "fill-red-500 text-red-500" : "text-white")} />
                  </button>
                </div>
                {wp.isAI && (
                  <div className="absolute top-4 left-4 px-2 py-1 bg-orange-500/80 backdrop-blur-md rounded text-[10px] font-bold uppercase tracking-wider">
                    AI
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredWallpapers.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-white/40">
            <ImageIcon className="w-16 h-16 mb-4 opacity-20" />
            <p className="text-lg">No wallpapers found</p>
            <button 
              onClick={() => {setSearchQuery(''); setSelectedCategory('All');}}
              className="mt-4 text-orange-500 hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </main>

      {/* Preview Modal */}
      <AnimatePresence>
        {isPreviewOpen && selectedWallpaper && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-black/95 backdrop-blur-xl"
          >
            <button 
              onClick={() => setIsPreviewOpen(false)}
              className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors z-50"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="flex flex-col lg:flex-row gap-12 items-center max-w-6xl w-full">
              {/* Phone Simulation */}
              <div className="relative w-[280px] h-[580px] md:w-[320px] md:h-[660px] bg-[#1a1a1a] rounded-[3rem] border-[8px] border-[#2a2a2a] shadow-2xl shadow-orange-500/10 overflow-hidden shrink-0">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-[#2a2a2a] rounded-b-2xl z-20" />
                <img 
                  src={selectedWallpaper.url} 
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                {/* Mock UI Overlay */}
                <div className="absolute inset-0 pointer-events-none p-8 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <div className="text-white text-sm font-medium">9:41</div>
                    <div className="flex gap-1.5">
                      <div className="w-4 h-4 rounded-full bg-white/20" />
                      <div className="w-4 h-4 rounded-full bg-white/20" />
                    </div>
                  </div>
                  <div className="grid grid-cols-4 gap-4 mb-12">
                    {[...Array(8)].map((_, i) => (
                      <div key={i} className="aspect-square bg-white/10 backdrop-blur-md rounded-xl" />
                    ))}
                  </div>
                </div>
              </div>

              {/* Info & Actions */}
              <div className="flex-1 text-center lg:text-left">
                <div className="mb-8">
                  <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-semibold text-orange-500 uppercase tracking-widest mb-4 inline-block">
                    {selectedWallpaper.category}
                  </span>
                  <h2 className="text-4xl md:text-6xl font-bold mb-4">{selectedWallpaper.title}</h2>
                  <p className="text-white/40 text-lg">High-resolution mobile wallpaper optimized for all devices.</p>
                </div>

                <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
                  <button 
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = selectedWallpaper.url;
                      link.download = `${selectedWallpaper.title.replace(/\s+/g, '-').toLowerCase()}.png`;
                      link.click();
                    }}
                    className="flex items-center gap-3 bg-white text-black px-8 py-4 rounded-2xl font-bold hover:bg-orange-500 hover:text-white transition-all active:scale-95"
                  >
                    <Download className="w-5 h-5" />
                    <span>Download Wallpaper</span>
                  </button>
                  <button 
                    onClick={() => toggleFavorite(selectedWallpaper.id)}
                    className="flex items-center gap-3 bg-white/5 border border-white/10 px-8 py-4 rounded-2xl font-bold hover:bg-white/10 transition-all"
                  >
                    <Heart className={cn("w-5 h-5", favorites.includes(selectedWallpaper.id) ? "fill-red-500 text-red-500" : "")} />
                    <span>{favorites.includes(selectedWallpaper.id) ? "Favorited" : "Add to Favorites"}</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* AI Generate Modal */}
      <AnimatePresence>
        {showAIModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#1a1a1a] border border-white/10 rounded-3xl p-8 max-w-xl w-full shadow-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-orange-500" />
                  </div>
                  <h3 className="text-xl font-bold">AI Wallpaper Studio</h3>
                </div>
                <button onClick={() => setShowAIModal(false)} className="text-white/40 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <p className="text-white/60 mb-6">Describe the wallpaper you want to create. Be specific about style, colors, and mood.</p>

              <div className="mb-6">
                <label className="text-xs font-bold uppercase tracking-widest text-white/40 mb-3 block">Choose Style</label>
                <div className="grid grid-cols-3 gap-2">
                  {AI_STYLE_PRESETS.map(style => (
                    <button
                      key={style.id}
                      onClick={() => setSelectedStyle(style.id)}
                      className={cn(
                        "px-3 py-2 rounded-xl text-xs font-medium transition-all border",
                        selectedStyle === style.id 
                          ? "bg-orange-500 border-orange-500 text-white" 
                          : "bg-white/5 border-white/10 text-white/60 hover:border-white/30"
                      )}
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
              </div>

              <textarea 
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="e.g., A cyberpunk city in the rain with purple and teal neon lights, cinematic perspective..."
                className="w-full h-32 bg-white/5 border border-white/10 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all resize-none mb-6"
              />

              <button 
                onClick={handleGenerateAI}
                disabled={isAIGenerating || !aiPrompt.trim()}
                className="w-full bg-orange-500 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-orange-600 transition-all active:scale-95"
              >
                {isAIGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Generating Magic...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>Generate Wallpaper</span>
                  </>
                )}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
